#include <iostream>
#include <stack>
#include <queue>
using namespace std;

void CheckIfPalindrome(string _word) {
	stack<char> mystack;
	string wordS;
	queue<char> myqueue;
	string wordQ;

	for (int i = 0; i < _word.length(); i++)
	{
		mystack.push(_word.at(i));
		myqueue.push(_word.at(i));
	}

	while (!mystack.empty()) {
		wordS += mystack.top();
		mystack.pop();
	}

	while (!myqueue.empty()) {
		wordQ += myqueue.front();
		myqueue.pop();
	}

	if (wordS == wordQ) {
		cout << _word << "\nIs a palindrome";
	}
	else {
		cout << _word << "\nIs not a palindrome";
	}
}

int main() {
	string word;

	cout << "This program checks if a word you enter is a Palindrome through \n Stacks and Queues" << endl << endl;

	cout << "Enter a word in lowercase: ";
	cin >> word;
	cout << endl;

	CheckIfPalindrome(word);

	return 0;
}