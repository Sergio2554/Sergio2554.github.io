#include <iostream>
using namespace std;

class Address {
private:
	// Variables
	string street;
	string city;
	string state;
	string zip;
public:
	// Constructors
	Address() {
		street = "99999 Sunset Boulevard";
		city = "Beverly Hills";
		state = "CA";
		zip = "99999";
	}
	Address(string _street, string _city, string _state, string _zip) {
		street = _street;
		city = _city;
		state = _state;
		zip = _zip;
	}

	// Get Functions
	string getStreet() {
		return street;
	}
	string getCity() {
		return city;
	}
	string getState() {
		return state;
	}
	
	string getZip(){
		return zip;
	}

	// Function
	void printAddress() {
		cout << getStreet() + ", " + getCity() + ", " + getState() + ", " + getZip() << endl;
	}
};