#include <iostream>
using namespace std;

class Name {
private:
	// Variables
	string firstName;
	string middleName;
	string lastName;
public:
	// Constructors
	Name() {
		firstName = "John";
		middleName = "H.";
		lastName = "Doe";
	}
	Name(string _firstName, string _middleName, string _lastName) {
		firstName = _firstName;
		middleName = _middleName;
		lastName = _lastName;
	}

	// Get Function
	string getFirstLast() {
		return firstName + " " + middleName + " " + lastName;
	}

	// Function
	void printName() {
		cout << getFirstLast() << endl;
	}
};
