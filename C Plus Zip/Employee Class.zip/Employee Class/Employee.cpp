#include <iostream>
#include "Name.h"
#include "Address.h"
#include "Employee.h"
using namespace std;

int main() {
	cout << "This program creates instances of an Employee class made from an Employee header file \n that inherits from an Address and Name header files" << endl << endl;

	// A default Employee Class
	Employee e;
	cout << "Employee e:" << endl;
	e.printEmployee();
	cout << endl;

	// An Employee Class filled with info
	Name n1("George", "Victor", "Meghabghab");
	Address a1("2639 Watkins St", "Bartlett", "WA", "48777");
	string ssn1 = "987-65-4321";
	Employee e1(n1, a1, ssn1);
	cout << "Employee e1:" << endl;
	e1.printEmployee();
	cout << endl;

	// A filled Employee Class with default name and address values
	Name n2;
	Address a2;
	string ssn2 = "000-00-0000";
	Employee e2(n2, a2, ssn2);
	cout << "Employee e2:" << endl;
	e2.printEmployee();
	cout << endl;

	// Another Filled Employee Class
	Name n3("Tyler", "Kelly", "Clarson");
	Address a3("1989 Parkson Ave", "Charlotte", "NC", "52819");
	string ssn3 = "453-03-7869";
	Employee e3(n3, a3, ssn3);
	cout << "Employee e3" << endl;
	e3.printEmployee();
		

	return 0;
}