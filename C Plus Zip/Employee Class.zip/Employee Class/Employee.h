#include <iostream>
using namespace std;

class Employee{//: public Name, public Address {
private:
	// Variable
	Name employeeName;
	Address employeeAddress;
	string sSN;
public:
	// Constructors
	Employee() {
		sSN = "999-99-9999";
	}
	Employee(Name _name, Address _address, string _sSN){ //: Name(_name), Address(_address){
		employeeName = _name;
		employeeAddress = _address;
		sSN = _sSN;
	}

	// Get Functions
	string getName() {
		return employeeName.getFirstLast();
	}
	string getAddress() {
		return employeeAddress.getStreet() + ", " + employeeAddress.getCity() + ", " + employeeAddress.getState() + ", " + employeeAddress.getZip();
	}
	string getsSN() {
		return sSN;
	}

	// Function
	void printEmployee() {
		// Just put multiple statements into one line
		cout << getName() << endl; cout << getAddress() << endl;  cout << getsSN() << endl;
	}
};