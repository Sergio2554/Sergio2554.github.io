#include <iostream>
#include <stack>
using namespace std;

bool isItBalanced(string inputExpr) {
	stack<char> s;
	// Memorize a place
	int x;

	for (int i = 0; i < inputExpr.length(); i++) {
		if (inputExpr[i] == '{' || inputExpr[i] == '[' || inputExpr[i] == '(') {
			s.push(inputExpr[i]);
			x = i;
		}
		
		if (inputExpr[i] == '}') {
			if (s.empty() || s.top() != '{') {
				cout << "Mismatch Found : " << inputExpr[i] << " at " << i << endl;
				return false;
			}
			else {
				s.pop();
			}
		}
		else if (inputExpr[i] == ']') {
			if (s.empty() || s.top() != '[') {
				cout << "Mismatch Found : " << inputExpr[i] << " at " << i << endl;
				return false;
			}
			else {
				s.pop();
			}
		}
		else if (inputExpr[i] == ')') {
			if (s.empty() || s.top() != '(') {
				cout << "Mismatch Found : " << inputExpr[i] << " at " << i << endl;
				return false;
			}
			else {
				s.pop();
			}
		}
	}

	cout << "No mismatches";
	if (!s.empty()) {
		cout << ", but there's an extra {, [, or ( in the expression." << endl;
	}
	else {
		cout << "." << endl;
	}

	return true;
}

int main() {
	string expr;
	bool result;

	cin >> expr;

	result = isItBalanced(expr);

	if (result == true) {
		cout << "Expected output : " << expr << "== 0;"
	}

	return 0;
}