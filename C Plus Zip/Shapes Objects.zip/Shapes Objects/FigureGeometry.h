#pragma once

#include <iostream>
using namespace std;

static const float PI = 3.14f;

class FigureGeometry {
public:
	virtual float getArea() const = 0;
	virtual float getPerimeter() const = 0;
};