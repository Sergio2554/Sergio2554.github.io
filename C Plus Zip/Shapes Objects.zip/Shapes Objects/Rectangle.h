#pragma once

#include <iostream>
#include "FigureGeometry.h"
#include "Point.h"
using namespace std;

class Rectangle: public FigureGeometry {
private:
	Point point;
public:
	Rectangle(Point p1){
		point = p1;
	}
	
	int getWidth() const {
		return point.getWidth();
	}
	int getHeight() const {
		return point.getHeight();
	}
	virtual float getArea() const {
		return getWidth() * getHeight();
	}
	virtual float getPerimeter() const {
		return (getWidth() + getHeight()) * 2;
	}
	void setPoint(int theWidth, int theHeight) {
		point = Point(theWidth, theHeight);
	}
};