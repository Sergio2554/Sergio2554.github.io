#include <iostream>
#include "Point.h"
#include "FigureGeometry.h"
#include "Circle.h"
#include "Square.h"
#include "Rectangle.h"
using namespace std;

void main() {
	cout << "This program creates various Shapes objects defined through several header files." << endl << endl;

	// Objects
	Circle c1(5);
	Square s1(Point(5,5));
	Rectangle r1(Point(5, 7));

	// Prints c1 Details
	cout << "Details of c1:\nradius: " << c1.getRadius()
		<< "\narea: " << c1.getArea() << "\nperimeter: " << c1.getPerimeter() << endl;

	// Prints s1 Details
	cout << "Details of s1:\nside length: " << s1.getSideLength()
	<< "\narea: " << s1.getArea() << "\nperimeter: " << s1.getPerimeter() << endl;

	// Prints r1 Details
	cout << "Details of r1:\nwidth: " << r1.getWidth() << "\nheight: " << r1.getHeight()
	<< "\narea: " << r1.getArea() << "\nperimeter: " << r1.getPerimeter() << endl;
}