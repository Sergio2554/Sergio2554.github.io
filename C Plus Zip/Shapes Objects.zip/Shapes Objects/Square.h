#pragma once

#include <iostream>
#include "FigureGeometry.h"
#include "Point.h"
using namespace std;

class Square: public FigureGeometry {
private:
	Point point;
public:
	Square(Point p1) {
		point = p1;
	}

	int getSideLength() const {
		return point.getWidth();
	}
	virtual float getArea() const {
		return getSideLength() * getSideLength();
	}
	virtual float getPerimeter() const {
		return getSideLength() * 4;
	}
	void setPoint(Point p1) {
		point = p1;
	}
};