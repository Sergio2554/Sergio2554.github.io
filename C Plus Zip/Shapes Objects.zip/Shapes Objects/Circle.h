#pragma once

#include <iostream>
#include "FigureGeometry.h"
using namespace std;

class Circle : public FigureGeometry {
private:
	float radius;
public:
	Circle(float theRadius) {
		radius = theRadius;
	}

	float getRadius() const {
		return radius;
	}
	virtual float getArea() const {
		return getRadius() * getRadius() * PI;
	}
	virtual float getPerimeter() const {
		return getRadius() * 2 * PI;
	}
	void setRadius(float theRadius) {
		radius = theRadius;
	}
};