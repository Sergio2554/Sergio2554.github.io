public class Exercise10_01{
    public static void main(String[] args){
        Time time1 = new Time();
        Time time2 = new Time(555550000);
        Time time3 = new Time(5, 23, 55);
        
        System.out.println(time1.hour + ":" + time1.minute + ":" + time1.second);
        System.out.println(time2.hour + ":" + time2.minute + ":" + time2.second);
        System.out.println(time3.hour + ":" + time3.minute + ":" + time3.second);
    }
}

class Time{
    long hour, minute, second;

    // Constructors
    public Time(){
        hour = ((((System.currentTimeMillis() / 1000) / 60) /60) % 24);
        minute = (((System.currentTimeMillis() / 1000) / 60) % 60);
        second = ((System.currentTimeMillis() / 1000) % 60);
    }
    public Time(int _hour, int _minute, int _second){
        hour = _hour;
        minute = _minute;
        second = _second;
    }
    public Time(long _milli){
      setTime(_milli);
    }

    // Getters
    public long getHour(){
        return hour;
    }
    public long getMinute(){
        return minute;
    }
    public long getSecond(){
        return second;
    }

    //Methods
    public void setTime(long _elapseTime){
        hour = ((((_elapseTime / 1000) / 60) /60) % 24);
        minute = (((_elapseTime / 1000) / 60) % 60);
        second = ((_elapseTime / 1000) % 60);
    }
    
}