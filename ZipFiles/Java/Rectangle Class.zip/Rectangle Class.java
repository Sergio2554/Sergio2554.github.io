public class Exercise09_01{
    Rectangle myRectangle1 = new Rectangle(4, 40);
    Rectangle myRectangle2 = new Rectangle(3.5, 35.9);
    
    public static void main(String[] args) {
        Rectangle myRectangle1 = new Rectangle(4, 40);
        Rectangle myRectangle2 = new Rectangle(3.5, 35.9);
    
        System.out.println("Rectangle 1 width, height, area, and perimeter in order: " +
            myRectangle1.width + ", " + myRectangle1.height + ", " +
            myRectangle1.getArea() + ", " + myRectangle1.getPerimeter());
            
        System.out.println("Rectangle 2 width, height, area, and perimeter in order: " +
            myRectangle2.width + ", " + myRectangle2.height + ", " +
            myRectangle2.getArea() + ", " + myRectangle2.getPerimeter());
    }
}

class Rectangle{
    double width = 1;
    double height = 1;
   
    // Constructors
    public Rectangle(){
        
    };
    public Rectangle(double _desiredWidth, double _desiredHeight){
        width = _desiredWidth; height = _desiredHeight;
    }
   
    // Methods
    public double getArea(){
        return width * height;
    }
    public double getPerimeter(){
        return (width*2) + (height*2);
    }
}