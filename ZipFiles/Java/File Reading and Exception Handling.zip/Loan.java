Hello.

How are you doing today?

Hope all is well.