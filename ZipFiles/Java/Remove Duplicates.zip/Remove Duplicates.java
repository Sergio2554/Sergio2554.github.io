import java.util.ArrayList;
import java.util.Scanner;

public class Exercise11_13 {
        public static void main(String[] args) {
        ArrayList<Integer> myList = new ArrayList<>();
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter ten integers: ");
        
        
        
        for (int i = 0; i < 10; i++){
            int no = input.nextInt();
            myList.add(no);
            //myList.add(input.nextInt());
        }
        
        removeDuplicate(myList);
    }
    
    public static void removeDuplicate(ArrayList<Integer> _list){
        ArrayList<Integer> list2 = new ArrayList<>();
        
        for (int i = 0; i < _list.size(); i++){
            if (!list2.contains(_list.get(i))){ 
                list2.add(_list.get(i));
            }
        }
        
        System.out.print("The distinct integers are ");
        for (int i = 0; i < list2.size(); i++) 
          System.out.print(list2.get(i) + " ");
    }
};