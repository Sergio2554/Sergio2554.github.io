﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Employee_Class
{
    internal class Employee
    {
        public string Name { get; }
        public int IdNumber { get; }
        public string Department { get; }
        public string Position { get; }

        public Employee(string _name, int _idNumber, string _department, string _position)
        {
            Name = _name;
            IdNumber = _idNumber;
            Department = _department;
            Position = _position;
        }

        public Employee(string _name, int _idNumber)
        {
            Name = _name;
            IdNumber = _idNumber;
            Department = "";
            Position = "";
        }

        public Employee()
        {
            Name = "";
            IdNumber = 0;
            Department = "";
            Position = "";
        }
    }
}
