﻿namespace Employee_Class
{
    partial class employeeInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            nameL1 = new Label();
            nameL2 = new Label();
            idNumL1 = new Label();
            idNumL2 = new Label();
            departmentL1 = new Label();
            departmentL2 = new Label();
            positionL1 = new Label();
            positionL2 = new Label();
            SuspendLayout();
            // 
            // nameL1
            // 
            nameL1.AutoSize = true;
            nameL1.Location = new Point(80, 9);
            nameL1.Name = "nameL1";
            nameL1.Size = new Size(39, 15);
            nameL1.TabIndex = 0;
            nameL1.Text = "Name";
            // 
            // nameL2
            // 
            nameL2.BorderStyle = BorderStyle.FixedSingle;
            nameL2.Location = new Point(12, 33);
            nameL2.Name = "nameL2";
            nameL2.Size = new Size(173, 23);
            nameL2.TabIndex = 1;
            nameL2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // idNumL1
            // 
            idNumL1.AutoSize = true;
            idNumL1.Location = new Point(208, 9);
            idNumL1.Name = "idNumL1";
            idNumL1.Size = new Size(65, 15);
            idNumL1.TabIndex = 2;
            idNumL1.Text = "ID Number";
            // 
            // idNumL2
            // 
            idNumL2.BorderStyle = BorderStyle.FixedSingle;
            idNumL2.Location = new Point(191, 33);
            idNumL2.Name = "idNumL2";
            idNumL2.Size = new Size(100, 23);
            idNumL2.TabIndex = 3;
            idNumL2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // departmentL1
            // 
            departmentL1.AutoSize = true;
            departmentL1.Location = new Point(329, 9);
            departmentL1.Name = "departmentL1";
            departmentL1.Size = new Size(70, 15);
            departmentL1.TabIndex = 4;
            departmentL1.Text = "Department";
            // 
            // departmentL2
            // 
            departmentL2.BorderStyle = BorderStyle.FixedSingle;
            departmentL2.Location = new Point(297, 33);
            departmentL2.Name = "departmentL2";
            departmentL2.Size = new Size(134, 23);
            departmentL2.TabIndex = 5;
            departmentL2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // positionL1
            // 
            positionL1.AutoSize = true;
            positionL1.Location = new Point(481, 9);
            positionL1.Name = "positionL1";
            positionL1.Size = new Size(50, 15);
            positionL1.TabIndex = 6;
            positionL1.Text = "Position";
            // 
            // positionL2
            // 
            positionL2.BorderStyle = BorderStyle.FixedSingle;
            positionL2.Location = new Point(437, 33);
            positionL2.Name = "positionL2";
            positionL2.Size = new Size(138, 23);
            positionL2.TabIndex = 7;
            positionL2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // employeeInfoForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(589, 74);
            Controls.Add(positionL2);
            Controls.Add(positionL1);
            Controls.Add(departmentL2);
            Controls.Add(departmentL1);
            Controls.Add(idNumL2);
            Controls.Add(idNumL1);
            Controls.Add(nameL2);
            Controls.Add(nameL1);
            Name = "employeeInfoForm";
            Text = "Employee Info";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label nameL1;
        private Label idNumL1;
        private Label departmentL1;
        private Label positionL1;
        public Label nameL2;
        public Label idNumL2;
        public Label departmentL2;
        public Label positionL2;
    }
}