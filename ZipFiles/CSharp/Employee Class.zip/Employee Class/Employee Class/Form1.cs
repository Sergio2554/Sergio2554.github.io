﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Class
{
    public partial class Form1 : Form
    {
        List<Employee> employees = new();

        Employee employee1 = new("Susan Meyers", 47899, "Accounting", "Vice President");
        Employee employee2 = new("Mark Jones", 39119, "IT", "Programmer");
        Employee employee3 = new("Joy Rogers", 81774, "Manufacturing", "Engineer");

        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("Select an employee for more detailed information");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add(employee1.Name);
            listBox1.Items.Add(employee2.Name);
            listBox1.Items.Add(employee3.Name);

            employees.Add(employee1);
            employees.Add(employee2);
            employees.Add(employee3);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            employeeInfoForm form2 = new();

            int index = listBox1.SelectedIndex;

            form2.nameL2.Text = employees[index].Name;
            form2.idNumL2.Text = employees[index].IdNumber.ToString();
            form2.departmentL2.Text = employees[index].Department;
            form2.positionL2.Text = employees[index].Position;

            form2.ShowDialog();
        }
    }
}
