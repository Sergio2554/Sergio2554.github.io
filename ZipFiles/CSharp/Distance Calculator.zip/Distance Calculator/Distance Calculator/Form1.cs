namespace Distance_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculate_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter outputFile;

                outputFile = File.CreateText(@"..\..\..\..\output.txt");

                int count = 1;

                if (int.TryParse(speedBox.Text, out int speed))
                {
                    if (int.TryParse(timeBox.Text, out int time))
                    {
                        while (count <= time)
                        {
                            outputFile.WriteLine("After hour "+ count +" the distance is " + speed * count);
                            count++;
                        }
                        outputFile.Close();

                        MessageBox.Show("Check Distance Calculator folder for output.txt");

                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Enter a Valid Number for Hours Traveled");
                    }
                }
                else
                {
                    MessageBox.Show("Enter a Valid Number for Distance Traveled");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void exit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}