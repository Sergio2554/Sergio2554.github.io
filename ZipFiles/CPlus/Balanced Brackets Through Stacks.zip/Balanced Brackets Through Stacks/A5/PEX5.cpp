#include <iostream>
#include <stack>
using namespace std;

// This Class will hold a bracket and its position in a string
class Expr {
public:
	// Curl or Bracket
	char CB;
	// Where in the line it is (position)
	int CBN;
	Expr(char _CB, int _CBN) {
		CB = _CB;
		CBN = _CBN;
	}

	// Get Methods
	char getCB() {
		return CB;
	}
	int getCBN() {
		return CBN;
	}
};

bool isItBalance(string inputExpr) {
	stack<Expr> s;

	for (int i = 0; i < inputExpr.length(); i++) {
		// All Begining Brackets will be added
		if (inputExpr[i] == '{' || inputExpr[i] == '[' || inputExpr[i] == '(') {
			Expr x(inputExpr[i], i);
			s.push(x);
		}

		// If the preceding bracket mismatches the current closing bracket, the loop will stop and return false
		if (inputExpr[i] == '}') {
			if (s.empty() || s.top().getCB() != '{') {
				cout << "Mismatch Found : " << inputExpr[i] << " at " << i << endl;
				return false;
			}
			else {
				s.pop();
			}
		}
		else if (inputExpr[i] == ']') {
			if (s.empty() || s.top().getCB() != '[') {
				cout << "Mismatch Found : " << inputExpr[i] << " at " << i << endl;
				return false;
			}
			else {
				s.pop();
			}
		}
		else if (inputExpr[i] == ')') {
			if (s.empty() || s.top().getCB() != '(') {
				cout << "Mismatch Found : " << inputExpr[i] << " at " << i << endl;
				return false;
			}
			else {
				s.pop();
			}
		}
	}

	// Extra Open Brackets in the given string are pointed out here
	if (!s.empty()) {
		cout << s.top().getCB() << " at position " << s.top().getCBN() << endl;
		s.pop();
		
		return false;
	}

	return true;
};

int main() {
	string expr;
	bool result;

	cout << "This program checks if any brackets in a math expression are mismatched through the use of Stacks and \ntells you where." << endl << endl;

	cout << "Enter your expression.\n";

	cin >> expr;

	cout << endl;

	result = isItBalance(expr);

	if (result == true) {
		cout << "No Mismatches found.";
	}
	else if (result == false) {
		cout << "Mismatch found.";
	}

	return 0;
};