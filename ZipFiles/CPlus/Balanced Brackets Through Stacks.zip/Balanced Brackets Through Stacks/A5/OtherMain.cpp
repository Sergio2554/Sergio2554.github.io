

int main() {
    /*
    Run:
    Enter your expression: {(0+1)*(2+3)}

        - [x] {(0+1)*(2+3)} == 1

    Enter your expression:� {(0+1)+[4*(2+3)]}

        - [x] {(0+1)+[4*(2+3)]} == 1

    Enter your expression:� {(0+1)+[4*(2+3)}}

        - [x] Mismatch found : } at 15
        - [x] {(0+1)+[4*(2+3)}} == 0
    */
    string expression = "{(0+1)+[4*(2+3)}}";
    expressionManager expr;
    cout << "Enter your expression: ";
    cin >> expression;
    if (expr.isItBalanced(expression)) {
        cout << expression << " == 1" << endl;
    }
    else {
        cout << expression << " == 0" << endl;
    }
}