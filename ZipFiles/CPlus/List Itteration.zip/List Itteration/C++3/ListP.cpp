#include <iostream>
#include <list>
using namespace std;

// The number of numbers asked to add to a list
int numberOfNumbersNeeded = 20;

// Print numbers of occurences in a given list
int countValue(list<int> front, const int item) {
	list<int>::iterator it;
	int numberOfOccurences = 0;

	for (it = front.begin(); it != front.end(); it++) {
		if (*it == item) {
			numberOfOccurences++;
		}
	}

	return numberOfOccurences;
}

// Prints Contents of a Given List
void writeLinkedList(list<int> _listToShow) {
	list<int>::iterator it;

	cout << "Run: ";

	for (it = _listToShow.begin(); it != _listToShow.end(); it++) {
		cout << *it << " ";
	}
}

int randomNoRanged4() {
	int randNo;
	bool rightNo = false;

	while (rightNo == false) {
		randNo = rand();
		if (randNo <= 4) {
			return randNo;
			rightNo = true;
		}
	}
};

int main() {
	/* Line below randomises seed for number generation.
	 * Comment out to see the same result come out over and over */
	srand(time(NULL));

	// List that'll be used
	list<int> myList;

	// Populates list
	for (int i = 1; i <= numberOfNumbersNeeded; i++) {
		myList.push_back(randomNoRanged4());
	}

	cout << "This program populates a list, then itterates through it with an itterator and\n gives you the number of occurences for each number" << endl << endl;

	// Print myList Contents
	writeLinkedList(myList);

	// Seperate next segment of output
	cout << endl;

	// Print out the number of occurences in myList; From 0 to 4.
	for (int i = 0; i <= 4; i++) {
		cout << i << " : " << countValue(myList, i);
		if (i != 4) {
			cout << ", ";
		}
	}

	return 0;
};