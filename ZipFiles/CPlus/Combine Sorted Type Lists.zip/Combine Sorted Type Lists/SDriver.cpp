#include <iostream>
#include "sortedType.h"
using namespace std;

int main() {
	cout << "This program combines two Sorted Type lists comprised of \n Item Type objects and arranges them in ascending order" << endl << endl;
	cout << "Item Type and Sorted Type header and cpp files were only provided to me, I did not code them myself." << endl << endl;

	// Declare 2 Sorted Type Lists
	SortedType mylist1;
	SortedType mylist2;

	// 3 items for list 1
	ItemType item2; item2.Initialize(2);
	ItemType item5; item5.Initialize(5);
	ItemType item8; item8.Initialize(8);
	mylist1.PutItem(item2); mylist1.PutItem(item5); mylist1.PutItem(item8);

	// 4 items for list 2
	ItemType item1; item1.Initialize(1);
	ItemType item3; item3.Initialize(3);
	ItemType item10; item10.Initialize(10);
	ItemType item9; item9.Initialize(9);
	mylist2.PutItem(item1); mylist2.PutItem(item3); mylist2.PutItem(item10); mylist2.PutItem(item9);


	// New List that will have both Lists Merged
	SortedType mlist;

	// Populate mlist with contents from given lists
	mylist1.ResetList();
	for (ItemType it; mylist1.GetLength() != 0; mylist1.DeleteItem(it)) {
		mylist1.ResetList();
		it = mylist1.GetNextItem();
		mlist.PutItem(it);
	}
	mylist1.~SortedType();

	mylist2.ResetList();
	for (ItemType it; mylist2.GetLength() != 0; mylist2.DeleteItem(it)) {
		mylist2.ResetList();
		it = mylist2.GetNextItem();
		mlist.PutItem(it);
	}
	mylist2.~SortedType();

	// Just in case
	mlist.ResetList();

	// Print Merged List Contents
	for (int i = 0; i < mlist.GetLength(); i++) {
		mlist.GetNextItem().Print(cout);
		cout << " ";
	}

	cout << endl;

	return 0;
}