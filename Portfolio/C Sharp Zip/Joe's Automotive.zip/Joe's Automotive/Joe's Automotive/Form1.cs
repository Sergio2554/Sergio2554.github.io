using System.IO;

namespace Joe_s_Automotive
{
    public partial class Form1 : Form
    {
        private bool invalidInputParts = false;
        private bool invalidInputLabor = false;
        private bool invalidInputPartsLetter = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void calculateBttn_Click(object sender, EventArgs e)
        {
            s_SAndLB.Text = "$" + (TotalCharges()).ToString();

            if (partsTB.TextLength == 0)
                s_PartsB.Text = "$0";
            else
                s_PartsB.Text = "$" + Parts();

            s_TaxB.Text = "$" + TaxCharges().ToString();

            s_FeesB.Text = "$" + (TotalCharges() + TaxCharges()).ToString();

            // Negative Number Input
            if (invalidInputParts == true)
            {
                MessageBox.Show("Please enter a number greater than 0 in the parts textbox");
                partsTB.Text = "";
                ClearFees();
                invalidInputParts = false;
            }

            if (invalidInputLabor == true)
            {
                MessageBox.Show("Please enter a number greater than 0 in the labor textbox");
                laborTB.Text = "";
                ClearFees();
                invalidInputLabor = false;
            }

            if (invalidInputPartsLetter == true)
            {
                partsTB.Text = "";
                ClearFees();
                invalidInputPartsLetter = false;
            }
        }

        private void clearBttn_Click(object sender, EventArgs e)
        {
            ClearOilLube(); ClearFlushes(); ClearMisc(); ClearOther(); ClearFees();
        }

        private void exitBttn_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// Methods
        // Charges
        double OilLubeCharges()
        {
            double price = 0;

            if (oilCB.Checked == true)
                price += 26.00;

            if (lubeCB.Checked == true)
                price += 18.00;

            return price;
        }

        double FlushCharges()
        {
            double price = 0;

            if (radiatorCB.Checked == true)
                price += 30.00;
            if (transmissionCB.Checked == true)
                price += 80.00;

            return price;
        }

        double MiscCharges()
        {
            double price = 0;

            if (inspectionCB.Checked == true)
                price += 15.00;
            if (mufflerCB.Checked == true)
                price += 100.00;
            if (tireCB.Checked == true)
                price += 20.00;

            return price;
        }

        double OtherCharges()
        {
            double price = 0;
            double parts = 0;
            double labor = 0;

            if (partsTB.TextLength > 0)
            {
                if (double.TryParse(partsTB.Text, out parts)) { }
                else 
                { 
                    if (invalidInputPartsLetter == !true)
                        MessageBox.Show("Please enter a valid number in the parts textbox");
                    invalidInputPartsLetter = true;
                }

                if (parts < 0)
                    invalidInputParts = true;
            }

            if (laborTB.TextLength > 0)
            {
                if (double.TryParse(laborTB.Text, out labor)) { }
                else { MessageBox.Show("Please enter a valid number in the labor textbox"); }

                if (labor < 0)
                    invalidInputLabor = true;
            }

            price += parts + labor;

            return Math.Round(price, 2);
        }

        double TaxCharges()
        {
            double tax = 0;
            double parts = 0;

            if (partsTB.TextLength > 0)
            {
                if (double.TryParse(partsTB.Text, out parts))
                {
                    tax += parts * .06;
                }
            }

            return Math.Round(tax, 2);
        }

        double TotalCharges()
        {
            return OilLubeCharges() + FlushCharges() + MiscCharges() + OtherCharges();
        }

        // Clear
        void ClearOilLube()
        {
            oilCB.Checked = false;
            lubeCB.Checked = false;
        }

        void ClearFlushes()
        {
            radiatorCB.Checked = false;
            transmissionCB.Checked = false;
        }

        void ClearMisc()
        {
            inspectionCB.Checked = false;
            mufflerCB.Checked = false;
            tireCB.Checked = false;
        }

        void ClearOther()
        {
            partsTB.Text = "";
            laborTB.Text = "";
        }

        void ClearFees()
        {
            s_SAndLB.Text = "";
            s_PartsB.Text = "";
            s_TaxB.Text = "";
            s_FeesB.Text = "";
        }

        string Parts()
        {
            double parts;

            if (double.TryParse(partsTB.Text, out parts))
            {
                return Math.Round(parts, 2).ToString();
            } else
            {
                return partsTB.Text;
            }
        }
    }
}