﻿namespace Joe_s_Automotive
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oilAndLubeGB = new System.Windows.Forms.GroupBox();
            this.oilCB = new System.Windows.Forms.CheckBox();
            this.lubeCB = new System.Windows.Forms.CheckBox();
            this.flushesGB = new System.Windows.Forms.GroupBox();
            this.transmissionCB = new System.Windows.Forms.CheckBox();
            this.radiatorCB = new System.Windows.Forms.CheckBox();
            this.miscGB = new System.Windows.Forms.GroupBox();
            this.mufflerCB = new System.Windows.Forms.CheckBox();
            this.tireCB = new System.Windows.Forms.CheckBox();
            this.inspectionCB = new System.Windows.Forms.CheckBox();
            this.partsAndLaborGB = new System.Windows.Forms.GroupBox();
            this.laborLB = new System.Windows.Forms.Label();
            this.partsLB = new System.Windows.Forms.Label();
            this.partsTB = new System.Windows.Forms.TextBox();
            this.laborTB = new System.Windows.Forms.TextBox();
            this.summaryGB = new System.Windows.Forms.GroupBox();
            this.s_FeesB = new System.Windows.Forms.Label();
            this.s_FeesLB = new System.Windows.Forms.Label();
            this.s_TaxLB = new System.Windows.Forms.Label();
            this.s_PartsLB = new System.Windows.Forms.Label();
            this.s_TaxB = new System.Windows.Forms.Label();
            this.s_SAndLB = new System.Windows.Forms.Label();
            this.s_SAndLLB = new System.Windows.Forms.Label();
            this.s_PartsB = new System.Windows.Forms.Label();
            this.calculateBttn = new System.Windows.Forms.Button();
            this.clearBttn = new System.Windows.Forms.Button();
            this.exitBttn = new System.Windows.Forms.Button();
            this.oilAndLubeGB.SuspendLayout();
            this.flushesGB.SuspendLayout();
            this.miscGB.SuspendLayout();
            this.partsAndLaborGB.SuspendLayout();
            this.summaryGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // oilAndLubeGB
            // 
            this.oilAndLubeGB.Controls.Add(this.oilCB);
            this.oilAndLubeGB.Controls.Add(this.lubeCB);
            this.oilAndLubeGB.Location = new System.Drawing.Point(12, 12);
            this.oilAndLubeGB.Name = "oilAndLubeGB";
            this.oilAndLubeGB.Size = new System.Drawing.Size(200, 78);
            this.oilAndLubeGB.TabIndex = 0;
            this.oilAndLubeGB.TabStop = false;
            this.oilAndLubeGB.Text = "Oil and Lube";
            // 
            // oilCB
            // 
            this.oilCB.AutoSize = true;
            this.oilCB.Location = new System.Drawing.Point(6, 22);
            this.oilCB.Name = "oilCB";
            this.oilCB.Size = new System.Drawing.Size(129, 19);
            this.oilCB.TabIndex = 1;
            this.oilCB.Text = "Oil Change ($26.00)";
            this.oilCB.UseVisualStyleBackColor = true;
            // 
            // lubeCB
            // 
            this.lubeCB.AutoSize = true;
            this.lubeCB.Location = new System.Drawing.Point(6, 47);
            this.lubeCB.Name = "lubeCB";
            this.lubeCB.Size = new System.Drawing.Size(117, 19);
            this.lubeCB.TabIndex = 2;
            this.lubeCB.Text = "Lube Job ($18.00)";
            this.lubeCB.UseVisualStyleBackColor = true;
            // 
            // flushesGB
            // 
            this.flushesGB.Controls.Add(this.transmissionCB);
            this.flushesGB.Controls.Add(this.radiatorCB);
            this.flushesGB.Location = new System.Drawing.Point(218, 12);
            this.flushesGB.Name = "flushesGB";
            this.flushesGB.Size = new System.Drawing.Size(200, 78);
            this.flushesGB.TabIndex = 0;
            this.flushesGB.TabStop = false;
            this.flushesGB.Text = "Flushes";
            // 
            // transmissionCB
            // 
            this.transmissionCB.AutoSize = true;
            this.transmissionCB.Location = new System.Drawing.Point(6, 47);
            this.transmissionCB.Name = "transmissionCB";
            this.transmissionCB.Size = new System.Drawing.Size(169, 19);
            this.transmissionCB.TabIndex = 4;
            this.transmissionCB.Text = "Transmission Flush ($80.00)";
            this.transmissionCB.UseVisualStyleBackColor = true;
            // 
            // radiatorCB
            // 
            this.radiatorCB.AutoSize = true;
            this.radiatorCB.Location = new System.Drawing.Point(6, 22);
            this.radiatorCB.Name = "radiatorCB";
            this.radiatorCB.Size = new System.Drawing.Size(145, 19);
            this.radiatorCB.TabIndex = 3;
            this.radiatorCB.Text = "Radiator Flush ($30.00)";
            this.radiatorCB.UseVisualStyleBackColor = true;
            // 
            // miscGB
            // 
            this.miscGB.Controls.Add(this.mufflerCB);
            this.miscGB.Controls.Add(this.tireCB);
            this.miscGB.Controls.Add(this.inspectionCB);
            this.miscGB.Location = new System.Drawing.Point(12, 96);
            this.miscGB.Name = "miscGB";
            this.miscGB.Size = new System.Drawing.Size(200, 100);
            this.miscGB.TabIndex = 0;
            this.miscGB.TabStop = false;
            this.miscGB.Text = "Misc.";
            // 
            // mufflerCB
            // 
            this.mufflerCB.AutoSize = true;
            this.mufflerCB.Location = new System.Drawing.Point(6, 47);
            this.mufflerCB.Name = "mufflerCB";
            this.mufflerCB.Size = new System.Drawing.Size(159, 19);
            this.mufflerCB.TabIndex = 6;
            this.mufflerCB.Text = "Replace Muffler ($100.00)";
            this.mufflerCB.UseVisualStyleBackColor = true;
            // 
            // tireCB
            // 
            this.tireCB.AutoSize = true;
            this.tireCB.Location = new System.Drawing.Point(6, 72);
            this.tireCB.Name = "tireCB";
            this.tireCB.Size = new System.Drawing.Size(137, 19);
            this.tireCB.TabIndex = 7;
            this.tireCB.Text = "Tire Rotation ($20.00)";
            this.tireCB.UseVisualStyleBackColor = true;
            // 
            // inspectionCB
            // 
            this.inspectionCB.AutoSize = true;
            this.inspectionCB.Location = new System.Drawing.Point(6, 22);
            this.inspectionCB.Name = "inspectionCB";
            this.inspectionCB.Size = new System.Drawing.Size(125, 19);
            this.inspectionCB.TabIndex = 5;
            this.inspectionCB.Text = "Inspection ($15.00)";
            this.inspectionCB.UseVisualStyleBackColor = true;
            // 
            // partsAndLaborGB
            // 
            this.partsAndLaborGB.Controls.Add(this.laborLB);
            this.partsAndLaborGB.Controls.Add(this.partsLB);
            this.partsAndLaborGB.Controls.Add(this.partsTB);
            this.partsAndLaborGB.Controls.Add(this.laborTB);
            this.partsAndLaborGB.Location = new System.Drawing.Point(218, 96);
            this.partsAndLaborGB.Name = "partsAndLaborGB";
            this.partsAndLaborGB.Size = new System.Drawing.Size(200, 100);
            this.partsAndLaborGB.TabIndex = 0;
            this.partsAndLaborGB.TabStop = false;
            this.partsAndLaborGB.Text = "Parts and Labor";
            // 
            // laborLB
            // 
            this.laborLB.AutoSize = true;
            this.laborLB.Location = new System.Drawing.Point(17, 60);
            this.laborLB.Name = "laborLB";
            this.laborLB.Size = new System.Drawing.Size(37, 15);
            this.laborLB.TabIndex = 6;
            this.laborLB.Text = "Labor";
            // 
            // partsLB
            // 
            this.partsLB.AutoSize = true;
            this.partsLB.Location = new System.Drawing.Point(21, 31);
            this.partsLB.Name = "partsLB";
            this.partsLB.Size = new System.Drawing.Size(33, 15);
            this.partsLB.TabIndex = 5;
            this.partsLB.Text = "Parts";
            // 
            // partsTB
            // 
            this.partsTB.Location = new System.Drawing.Point(60, 28);
            this.partsTB.Name = "partsTB";
            this.partsTB.Size = new System.Drawing.Size(100, 23);
            this.partsTB.TabIndex = 3;
            // 
            // laborTB
            // 
            this.laborTB.Location = new System.Drawing.Point(60, 57);
            this.laborTB.Name = "laborTB";
            this.laborTB.Size = new System.Drawing.Size(100, 23);
            this.laborTB.TabIndex = 4;
            // 
            // summaryGB
            // 
            this.summaryGB.Controls.Add(this.s_FeesB);
            this.summaryGB.Controls.Add(this.s_FeesLB);
            this.summaryGB.Controls.Add(this.s_TaxLB);
            this.summaryGB.Controls.Add(this.s_PartsLB);
            this.summaryGB.Controls.Add(this.s_TaxB);
            this.summaryGB.Controls.Add(this.s_SAndLB);
            this.summaryGB.Controls.Add(this.s_SAndLLB);
            this.summaryGB.Controls.Add(this.s_PartsB);
            this.summaryGB.Location = new System.Drawing.Point(70, 202);
            this.summaryGB.Name = "summaryGB";
            this.summaryGB.Size = new System.Drawing.Size(296, 126);
            this.summaryGB.TabIndex = 0;
            this.summaryGB.TabStop = false;
            this.summaryGB.Text = "Summary";
            // 
            // s_FeesB
            // 
            this.s_FeesB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.s_FeesB.Location = new System.Drawing.Point(154, 97);
            this.s_FeesB.Name = "s_FeesB";
            this.s_FeesB.Size = new System.Drawing.Size(100, 23);
            this.s_FeesB.TabIndex = 7;
            this.s_FeesB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // s_FeesLB
            // 
            this.s_FeesLB.AutoSize = true;
            this.s_FeesLB.Location = new System.Drawing.Point(84, 98);
            this.s_FeesLB.Name = "s_FeesLB";
            this.s_FeesLB.Size = new System.Drawing.Size(58, 15);
            this.s_FeesLB.TabIndex = 6;
            this.s_FeesLB.Text = "Total Fees";
            // 
            // s_TaxLB
            // 
            this.s_TaxLB.AutoSize = true;
            this.s_TaxLB.Location = new System.Drawing.Point(64, 67);
            this.s_TaxLB.Name = "s_TaxLB";
            this.s_TaxLB.Size = new System.Drawing.Size(78, 15);
            this.s_TaxLB.TabIndex = 4;
            this.s_TaxLB.Text = "Tax (on parts)";
            // 
            // s_PartsLB
            // 
            this.s_PartsLB.AutoSize = true;
            this.s_PartsLB.Location = new System.Drawing.Point(109, 43);
            this.s_PartsLB.Name = "s_PartsLB";
            this.s_PartsLB.Size = new System.Drawing.Size(33, 15);
            this.s_PartsLB.TabIndex = 2;
            this.s_PartsLB.Text = "Parts";
            // 
            // s_TaxB
            // 
            this.s_TaxB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.s_TaxB.Location = new System.Drawing.Point(154, 66);
            this.s_TaxB.Name = "s_TaxB";
            this.s_TaxB.Size = new System.Drawing.Size(100, 23);
            this.s_TaxB.TabIndex = 5;
            this.s_TaxB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // s_SAndLB
            // 
            this.s_SAndLB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.s_SAndLB.Location = new System.Drawing.Point(154, 19);
            this.s_SAndLB.Name = "s_SAndLB";
            this.s_SAndLB.Size = new System.Drawing.Size(100, 23);
            this.s_SAndLB.TabIndex = 1;
            this.s_SAndLB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // s_SAndLLB
            // 
            this.s_SAndLLB.AutoSize = true;
            this.s_SAndLLB.Location = new System.Drawing.Point(44, 19);
            this.s_SAndLLB.Name = "s_SAndLLB";
            this.s_SAndLLB.Size = new System.Drawing.Size(100, 15);
            this.s_SAndLLB.TabIndex = 0;
            this.s_SAndLLB.Text = "Service and Labor";
            // 
            // s_PartsB
            // 
            this.s_PartsB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.s_PartsB.Location = new System.Drawing.Point(154, 42);
            this.s_PartsB.Name = "s_PartsB";
            this.s_PartsB.Size = new System.Drawing.Size(100, 23);
            this.s_PartsB.TabIndex = 3;
            this.s_PartsB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateBttn
            // 
            this.calculateBttn.Location = new System.Drawing.Point(100, 334);
            this.calculateBttn.Name = "calculateBttn";
            this.calculateBttn.Size = new System.Drawing.Size(75, 23);
            this.calculateBttn.TabIndex = 3;
            this.calculateBttn.Text = "Calculate";
            this.calculateBttn.UseVisualStyleBackColor = true;
            this.calculateBttn.Click += new System.EventHandler(this.calculateBttn_Click);
            // 
            // clearBttn
            // 
            this.clearBttn.Location = new System.Drawing.Point(181, 334);
            this.clearBttn.Name = "clearBttn";
            this.clearBttn.Size = new System.Drawing.Size(75, 23);
            this.clearBttn.TabIndex = 4;
            this.clearBttn.Text = "Clear";
            this.clearBttn.UseVisualStyleBackColor = true;
            this.clearBttn.Click += new System.EventHandler(this.clearBttn_Click);
            // 
            // exitBttn
            // 
            this.exitBttn.Location = new System.Drawing.Point(262, 334);
            this.exitBttn.Name = "exitBttn";
            this.exitBttn.Size = new System.Drawing.Size(75, 23);
            this.exitBttn.TabIndex = 5;
            this.exitBttn.Text = "Exit";
            this.exitBttn.UseVisualStyleBackColor = true;
            this.exitBttn.Click += new System.EventHandler(this.exitBttn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 369);
            this.Controls.Add(this.calculateBttn);
            this.Controls.Add(this.clearBttn);
            this.Controls.Add(this.exitBttn);
            this.Controls.Add(this.summaryGB);
            this.Controls.Add(this.partsAndLaborGB);
            this.Controls.Add(this.miscGB);
            this.Controls.Add(this.flushesGB);
            this.Controls.Add(this.oilAndLubeGB);
            this.Name = "Form1";
            this.Text = "Joe\'s Automotive";
            this.oilAndLubeGB.ResumeLayout(false);
            this.oilAndLubeGB.PerformLayout();
            this.flushesGB.ResumeLayout(false);
            this.flushesGB.PerformLayout();
            this.miscGB.ResumeLayout(false);
            this.miscGB.PerformLayout();
            this.partsAndLaborGB.ResumeLayout(false);
            this.partsAndLaborGB.PerformLayout();
            this.summaryGB.ResumeLayout(false);
            this.summaryGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox oilAndLubeGB;
        private CheckBox oilCB;
        private CheckBox lubeCB;
        private GroupBox flushesGB;
        private CheckBox transmissionCB;
        private CheckBox radiatorCB;
        private GroupBox miscGB;
        private CheckBox mufflerCB;
        private CheckBox tireCB;
        private CheckBox inspectionCB;
        private GroupBox partsAndLaborGB;
        private Label laborLB;
        private Label partsLB;
        private TextBox partsTB;
        private TextBox laborTB;
        private GroupBox summaryGB;
        private Button calculateBttn;
        private Button clearBttn;
        private Button exitBttn;
        private Label s_FeesB;
        private Label s_FeesLB;
        private Label s_TaxLB;
        private Label s_PartsLB;
        private Label s_TaxB;
        private Label s_SAndLB;
        private Label s_SAndLLB;
        private Label s_PartsB;
    }
}