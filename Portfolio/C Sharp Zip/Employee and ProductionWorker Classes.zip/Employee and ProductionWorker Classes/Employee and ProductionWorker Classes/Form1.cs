namespace Employee_and_ProductionWorker_Classes
{
    public partial class Form1 : Form
    {
        List<ProductionWorker> productionWorkerList = new();

        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("Add and view employees into and from the listbox");
        }

        private void addB_Click(object sender, EventArgs e)
        {
            productionWorkerList.Add(
                new ProductionWorker(
                    nameTB.Text,
                    int.Parse(iDNumberTB.Text),
                    ShiftRadioB(),
                    decimal.Parse(hourlyPayTB.Text)
                )
            );

                                                    // End of List
            listBox1.Items.Add(productionWorkerList[productionWorkerList.Count - 1].Name);

            nameTB.Clear();
            iDNumberTB.Clear();
            dayRB.Checked = false;
            nightRB.Checked = false;
            hourlyPayTB.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;

            MessageBox.Show(
                "Worker Name: " + productionWorkerList[index].Name + "\n" +
                "ID Number: " + productionWorkerList[index].IDNumber.ToString() + "\n" +
                "Shift: " + productionWorkerList[index].GetShift() + "\n" +
                "Hourly Rate: " + productionWorkerList[index].HourlyRate.ToString()
            );
        }

        int ShiftRadioB()
        {
            if (dayRB.Checked)
                return 1;
            else if (nightRB.Checked)
                return 2;
            else return 3;
        }


    }
}