﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker_Classes
{
    internal abstract class Employee
    {
        private string name;
        private int iDNumber;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int IDNumber
        {
            get { return iDNumber; }
            set { iDNumber = value; }
        }

        public Employee(string _name, int _iDNumber)
        {
            name = _name;
            iDNumber = _iDNumber;
        }
    }
}