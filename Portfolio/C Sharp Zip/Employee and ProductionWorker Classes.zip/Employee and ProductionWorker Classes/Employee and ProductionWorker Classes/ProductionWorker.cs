﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_and_ProductionWorker_Classes
{
    internal class ProductionWorker : Employee
    {
        private int shiftNumber;
        private decimal hourlyRate;

        public decimal HourlyRate
        {
            get { return hourlyRate; }
            set { hourlyRate = value; }
        }

        public ProductionWorker(string _name, int _iDNumber, int _shiftnum, decimal hourlyrate) : base(_name, _iDNumber)
        {
            shiftNumber = _shiftnum;
            hourlyRate = hourlyrate;
        }

        public string GetShift()
        {
            if (shiftNumber == 1)
                return "Day";
            else if (shiftNumber == 2)
                return "Night";
            else
                return "N/A";
        }


    }
}