﻿namespace Employee_and_ProductionWorker_Classes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            nightRB = new RadioButton();
            hourlyPayL = new Label();
            nameL = new Label();
            hourlyPayTB = new TextBox();
            dayRB = new RadioButton();
            iDNumberL = new Label();
            nameTB = new TextBox();
            shiftL = new Label();
            iDNumberTB = new TextBox();
            addB = new Button();
            listBox1 = new ListBox();
            groupBox2 = new GroupBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(nightRB);
            groupBox1.Controls.Add(hourlyPayL);
            groupBox1.Controls.Add(nameL);
            groupBox1.Controls.Add(hourlyPayTB);
            groupBox1.Controls.Add(dayRB);
            groupBox1.Controls.Add(iDNumberL);
            groupBox1.Controls.Add(nameTB);
            groupBox1.Controls.Add(shiftL);
            groupBox1.Controls.Add(iDNumberTB);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(191, 146);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Add an Employee";
            // 
            // nightRB
            // 
            nightRB.AutoSize = true;
            nightRB.Location = new Point(127, 80);
            nightRB.Name = "nightRB";
            nightRB.Size = new Size(55, 19);
            nightRB.TabIndex = 10;
            nightRB.TabStop = true;
            nightRB.Text = "Night";
            nightRB.UseVisualStyleBackColor = true;
            // 
            // hourlyPayL
            // 
            hourlyPayL.AutoSize = true;
            hourlyPayL.Location = new Point(8, 108);
            hourlyPayL.Name = "hourlyPayL";
            hourlyPayL.Size = new Size(65, 15);
            hourlyPayL.TabIndex = 3;
            hourlyPayL.Text = "Hourly Pay";
            // 
            // nameL
            // 
            nameL.AutoSize = true;
            nameL.Location = new Point(31, 25);
            nameL.Name = "nameL";
            nameL.Size = new Size(39, 15);
            nameL.TabIndex = 0;
            nameL.Text = "Name";
            // 
            // hourlyPayTB
            // 
            hourlyPayTB.Location = new Point(76, 105);
            hourlyPayTB.Name = "hourlyPayTB";
            hourlyPayTB.Size = new Size(100, 23);
            hourlyPayTB.TabIndex = 8;
            // 
            // dayRB
            // 
            dayRB.AutoSize = true;
            dayRB.Location = new Point(76, 80);
            dayRB.Name = "dayRB";
            dayRB.Size = new Size(45, 19);
            dayRB.TabIndex = 9;
            dayRB.TabStop = true;
            dayRB.Text = "Day";
            dayRB.UseVisualStyleBackColor = true;
            // 
            // iDNumberL
            // 
            iDNumberL.AutoSize = true;
            iDNumberL.Location = new Point(8, 54);
            iDNumberL.Name = "iDNumberL";
            iDNumberL.Size = new Size(65, 15);
            iDNumberL.TabIndex = 1;
            iDNumberL.Text = "ID Number";
            // 
            // nameTB
            // 
            nameTB.Location = new Point(76, 22);
            nameTB.Name = "nameTB";
            nameTB.Size = new Size(100, 23);
            nameTB.TabIndex = 5;
            // 
            // shiftL
            // 
            shiftL.AutoSize = true;
            shiftL.Location = new Point(42, 84);
            shiftL.Name = "shiftL";
            shiftL.Size = new Size(31, 15);
            shiftL.TabIndex = 2;
            shiftL.Text = "Shift";
            // 
            // iDNumberTB
            // 
            iDNumberTB.Location = new Point(76, 51);
            iDNumberTB.Name = "iDNumberTB";
            iDNumberTB.Size = new Size(100, 23);
            iDNumberTB.TabIndex = 6;
            // 
            // addB
            // 
            addB.Location = new Point(102, 164);
            addB.Name = "addB";
            addB.Size = new Size(75, 23);
            addB.TabIndex = 5;
            addB.Text = "Add";
            addB.UseVisualStyleBackColor = true;
            addB.Click += addB_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(6, 16);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(172, 124);
            listBox1.TabIndex = 6;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(listBox1);
            groupBox2.Location = new Point(209, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(186, 146);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "View Employee";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(409, 202);
            Controls.Add(groupBox2);
            Controls.Add(addB);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Add and View Employees";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton nightRB;
        private Label hourlyPayL;
        private Label nameL;
        private TextBox hourlyPayTB;
        private RadioButton dayRB;
        private Label iDNumberL;
        private TextBox nameTB;
        private Label shiftL;
        private TextBox iDNumberTB;
        private Button addB;
        private ListBox listBox1;
        private GroupBox groupBox2;
    }
}