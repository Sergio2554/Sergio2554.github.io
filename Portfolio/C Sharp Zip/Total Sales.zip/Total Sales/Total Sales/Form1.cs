namespace Total_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("This program calculates the sum in Sales.txt");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            float sum = 0;
            float num;

            try
            {
                StreamReader inputFile = File.OpenText(@"..\..\..\..\Sales.txt");

                while (!inputFile.EndOfStream)
                {
                    num = float.Parse(inputFile.ReadLine());
                    listBox1.Items.Add(num.ToString());

                    sum += num;
                }

                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            label1.Text = sum.ToString();
        }
    }
}