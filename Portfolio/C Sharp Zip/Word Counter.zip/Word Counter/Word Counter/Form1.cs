namespace Word_Counter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("This program counts how many words you type");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = WordCount(textBox1.Text);
        }

        string WordCount(string sentence)
        {
            int sum = 0;
            int index;
            bool morewords = true;

            for (index = 0; index < sentence.Length && morewords == true; index++)
            {
                if (sentence[index] == (char)32)
                {
                    sum++;
                    morewords = false;

                    for (int i = index; i < sentence.Length; i++)
                    {
                        if (sentence[i] != (char)32)
                        {
                            morewords = true;
                            index = i;

                            // End for loop
                            i = sentence.Length + 1;
                                        // if at End of word   // if ends with a space
                        } else if (i == sentence.Length - 1 && sentence[i] == (char)32)
                            { sum--; }
                    }
                }
            }
            if (sentence.Length > 0)
                sum++;

            return sum.ToString();
        }
    }
}