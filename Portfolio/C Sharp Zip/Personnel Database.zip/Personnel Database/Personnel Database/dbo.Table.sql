﻿CREATE TABLE [dbo].[Personnel]
(
	[EmployeeID] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Position] NVARCHAR(50) NOT NULL, 
    [Houry Pay Rate] NCHAR(10) NOT NULL
)
