namespace Lab4
{
    public partial class form : Form
    {
        string color1;
        string color2;

        public form()
        {
            InitializeComponent();
        }

        private void mix_Click(object sender, EventArgs e)
        {
            switch (color1)
            {
                case "red":
                    if (color2 == "red")
                        BackColor = Color.Red;
                    if (color2 == "blue")
                        BackColor = Color.Purple;
                    if (color2 == "yellow")
                        BackColor = Color.Orange;
                    break;
                case "blue":
                    if (color2 == "red")
                        BackColor = Color.Purple;
                    if (color2 == "blue")
                        BackColor = Color.Blue;
                    if (color2 == "yellow")
                        BackColor = Color.Green;
                    break;
                case "yellow":
                    if (color2 == "red")
                        BackColor = Color.Orange;
                    if (color2 == "blue")
                        BackColor = Color.Green;
                    if (color2 == "yellow")
                        BackColor = Color.Yellow;
                    break;
            }
        }

        private void red1_CheckedChanged(object sender, EventArgs e)
        {
            color1 = "red";
        }

        private void blue1_CheckedChanged(object sender, EventArgs e)
        {
            color1 = "blue";
        }

        private void yellow1_CheckedChanged(object sender, EventArgs e)
        {
            color1 = "yellow";
        }

        private void red2_CheckedChanged(object sender, EventArgs e)
        {
            color2 = "red";
        }

        private void blue2_CheckedChanged(object sender, EventArgs e)
        {
            color2 = "blue";
        }

        private void yellow2_CheckedChanged(object sender, EventArgs e)
        {
            color2 = "yellow";
        }
    }
}