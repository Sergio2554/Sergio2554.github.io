﻿namespace Lab4
{
    partial class form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.red1 = new System.Windows.Forms.RadioButton();
            this.blue1 = new System.Windows.Forms.RadioButton();
            this.yellow1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.yellow2 = new System.Windows.Forms.RadioButton();
            this.blue2 = new System.Windows.Forms.RadioButton();
            this.red2 = new System.Windows.Forms.RadioButton();
            this.mix = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.red1);
            this.groupBox1.Controls.Add(this.blue1);
            this.groupBox1.Controls.Add(this.yellow1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(164, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "First Color";
            // 
            // red1
            // 
            this.red1.AutoSize = true;
            this.red1.Location = new System.Drawing.Point(28, 22);
            this.red1.Name = "red1";
            this.red1.Size = new System.Drawing.Size(45, 19);
            this.red1.TabIndex = 0;
            this.red1.Text = "Red";
            this.red1.UseVisualStyleBackColor = true;
            this.red1.CheckedChanged += new System.EventHandler(this.red1_CheckedChanged);
            // 
            // blue1
            // 
            this.blue1.AutoSize = true;
            this.blue1.Location = new System.Drawing.Point(28, 47);
            this.blue1.Name = "blue1";
            this.blue1.Size = new System.Drawing.Size(48, 19);
            this.blue1.TabIndex = 1;
            this.blue1.Text = "Blue";
            this.blue1.UseVisualStyleBackColor = true;
            this.blue1.CheckedChanged += new System.EventHandler(this.blue1_CheckedChanged);
            // 
            // yellow1
            // 
            this.yellow1.AutoSize = true;
            this.yellow1.Location = new System.Drawing.Point(28, 72);
            this.yellow1.Name = "yellow1";
            this.yellow1.Size = new System.Drawing.Size(59, 19);
            this.yellow1.TabIndex = 2;
            this.yellow1.Text = "Yellow";
            this.yellow1.UseVisualStyleBackColor = true;
            this.yellow1.CheckedChanged += new System.EventHandler(this.yellow1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.yellow2);
            this.groupBox2.Controls.Add(this.blue2);
            this.groupBox2.Controls.Add(this.red2);
            this.groupBox2.Location = new System.Drawing.Point(182, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(164, 100);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Second Color";
            // 
            // yellow2
            // 
            this.yellow2.AutoSize = true;
            this.yellow2.Location = new System.Drawing.Point(28, 72);
            this.yellow2.Name = "yellow2";
            this.yellow2.Size = new System.Drawing.Size(59, 19);
            this.yellow2.TabIndex = 5;
            this.yellow2.Text = "Yellow";
            this.yellow2.UseVisualStyleBackColor = true;
            this.yellow2.CheckedChanged += new System.EventHandler(this.yellow2_CheckedChanged);
            // 
            // blue2
            // 
            this.blue2.AutoSize = true;
            this.blue2.Location = new System.Drawing.Point(28, 47);
            this.blue2.Name = "blue2";
            this.blue2.Size = new System.Drawing.Size(48, 19);
            this.blue2.TabIndex = 4;
            this.blue2.Text = "Blue";
            this.blue2.UseVisualStyleBackColor = true;
            this.blue2.CheckedChanged += new System.EventHandler(this.blue2_CheckedChanged);
            // 
            // red2
            // 
            this.red2.AutoSize = true;
            this.red2.Location = new System.Drawing.Point(28, 22);
            this.red2.Name = "red2";
            this.red2.Size = new System.Drawing.Size(45, 19);
            this.red2.TabIndex = 3;
            this.red2.Text = "Red";
            this.red2.UseVisualStyleBackColor = true;
            this.red2.CheckedChanged += new System.EventHandler(this.red2_CheckedChanged);
            // 
            // mix
            // 
            this.mix.Location = new System.Drawing.Point(143, 118);
            this.mix.Name = "mix";
            this.mix.Size = new System.Drawing.Size(75, 23);
            this.mix.TabIndex = 1;
            this.mix.Text = "Mix!";
            this.mix.UseVisualStyleBackColor = true;
            this.mix.Click += new System.EventHandler(this.mix_Click);
            // 
            // form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(359, 150);
            this.Controls.Add(this.mix);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "form";
            this.Text = "Color Mixer";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton red1;
        private RadioButton blue1;
        private RadioButton yellow1;
        private GroupBox groupBox2;
        private RadioButton yellow2;
        private RadioButton blue2;
        private RadioButton red2;
        private Button mix;
    }
}