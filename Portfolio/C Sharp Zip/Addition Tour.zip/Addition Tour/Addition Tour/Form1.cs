namespace Addition_Tour
{
    public partial class Form1 : Form
    {
        Random rand = new Random();

        int randomInt1;
        int randomInt2;

        public Form1()
        {
            InitializeComponent();
            RandomLabel();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(answerBox.Text, out int answer))
            {
                if (answer == randomInt1 + randomInt2)
                {
                    MessageBox.Show("Correct!");
                }
                else
                {
                    MessageBox.Show("That wasn't quite right... Try another!");
                }
                RandomLabel();
            }
            else
            {
                MessageBox.Show("Please enter a valid number");
            }
        }

        void RandomLabel()
        {
            randomInt1 = rand.Next(401) + 100;
            randomInt2 = rand.Next(401) + 100;

            questionBox.Text = randomInt1 + " + " + randomInt2 + " = ";

            answerBox.Text = "";
        }
    }
}